# 2. Escriba un programa que solicite el nombre del usuario y luego muestre el mensaje de salida
# “Hola nombre”, donde nombre es el nombre que ingresó el usuario.

def nombre ():
    nombre = input ("Hola!, por favor escribe tu nombre.")
    return print ("Hola " + nombre)

nombre()