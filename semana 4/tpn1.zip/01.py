def imprimir_nombre(nombre):
    print(nombre)

imprimir_nombre()

