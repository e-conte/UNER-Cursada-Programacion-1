# 1. Mostrar por pantalla: “Hola Mundo, esto es Python!”.

def hola_mundo():
    return print ("Hola Mundo, esto es Python!")

hola_mundo()