#   PARTE 2 - ESTRUCTURAS DE CONTROL
#   7.  Que imprima todos los números entre el 100 y el 199.

def numeros_de_100_a_199():

    for i in range (100,200):
        print (i)
        #empieza en 100 inclusive, y termina en 200 no inclusive

numeros_de_100_a_199()